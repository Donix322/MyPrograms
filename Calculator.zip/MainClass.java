

class MainClass{

	public static void main(String[] arges){
	
		Calculator c = new Calculator();
		c.show();
	}
}