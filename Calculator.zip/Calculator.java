import javax.swing.*; 
import java.awt.*;
public class Calculator extends MainClass{
	
	private JFrame frame;
	private JPanel buttonPanel;
	private JPanel operationPanel;
	private GridLayout grid;
	private JTextField text;
	private JButton One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Zero, 
			Addition, Subtraction, Multiplication, Division, 
			Equals,  Clear, DecimalPoint;
			
	public Calculator(){
	
	frame = new JFrame();
		frame.setTitle("Calculator");
		frame.setSize(480,580);
		frame.setLocation(150,150);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
	
		//buttons
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout (3,3));
		buttonPanel.setBackground(Color.cyan);

		
		One = new JButton("1");
		Two = new JButton("2");
		Three = new JButton("3");
		Four = new JButton("4");
		Five = new JButton("5");
		Six = new JButton("6");
		Seven = new JButton("7");
		Eight = new JButton("8");
		Nine = new JButton("9");
		Zero = new JButton("0");
		DecimalPoint = new JButton(".");
		Clear = new JButton("C");
		
		
		
		
		operationPanel = new JPanel();
		//operationPanel.setLayout(new GridLayout (3,3));
		//operationPanel.setBackground(Color.white);
		//operationPanel.setBorder(BorderFactory.createLineBorder(Color.black,1));
		Division = new JButton("/");
		Multiplication = new JButton("*");
		Subtraction = new JButton("-");
		Addition = new JButton("+");
		Equals = new JButton("=");
		
		
		//add
		frame.setLayout(new GridLayout(6,3,10,10));
		buttonPanel.add(One);
		buttonPanel.add(Two);
		buttonPanel.add(Three);
		buttonPanel.add(Four);
		buttonPanel.add(Five);
		buttonPanel.add(Six);
		buttonPanel.add(Seven);
		buttonPanel.add(Eight);
		buttonPanel.add(Nine);
		buttonPanel.add(Zero);
		buttonPanel.add(DecimalPoint);
		buttonPanel.add(Clear);
		buttonPanel.add(Division);
		buttonPanel.add(Multiplication);
		buttonPanel.add(Subtraction);
		buttonPanel.add(Addition);
		buttonPanel.add(Equals);
		frame.add(buttonPanel);
		
}
 public void show() {
	 
	frame.setVisible(true);
 }
}   